Put your licensed Bogue Regular font files here:

- `Bogue-Regular.woff2`
- `Bogue-Regular.woff` (optional fallback)

`index.html` already declares the `@font-face` rule that points here, so
the title ("Customize your AFO.") will pick it up automatically once the
files exist — no code changes needed.
